# Test driven introduction to Solidity

This repository contains the full source code of test suits and the smart contact from the article: [Ethereum: Test driven introduction to Solidity](https://michalzalecki.com/ethereum-test-driven-introduction-to-solidity/)

## Usage

    npm run test                # run tests
    npm run test:coverage       # check tests coverage
