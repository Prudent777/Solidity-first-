module.exports = {
  copyPackages: ["openzeppelin-solidity"]
};
